from raytracing import *

lenses = AchromatDoubletLens.all()
for lens in lenses:
  print(lens.__init__())


