TITLE       = ""
DESCRIPTION = """
"""

from raytracing import *

def exampleCode():
	pass
    # path.display(comments=DESCRIPTION)

if __name__ == "__main__":
    exampleCode()